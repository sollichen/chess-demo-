<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ChessController extends Controller
{
    
    protected function getShowDataByFen($fen){
        $repsource = [
            'p'=>'Bp.svg',
            'n'=>'Bn.svg',
            'b'=>'Bb.svg',
            'r'=>'Br.svg',
            'q'=>'Bq.svg',
            'k'=>'Bk.svg',

            'P'=>'Wp.svg',
            'N'=>'Wn.svg',
            'B'=>'Wb.svg',
            'R'=>'Wr.svg',
            'Q'=>'Wq.svg',
            'K'=>'Wk.svg',
        ];
        
        if(empty($fen)){
             die("wrong parameter...");
            #return $this->rand();
        }
        
        
        $fenFirstData= explode(" ", $fen);
        $fenrows = explode("/", $fenFirstData[0]);
        $rowNum = count($fenrows);
        $error_msg = false;
        if($rowNum != 8){
            die("fen wrong parater...");
        }
        
        $showData = [];
        for($i = 0 ; $i < $rowNum ; $i++){
            $fenlines =  str_split($fenrows[$i]);
            $lineRecordData = [];
            $lineRecordData[] = $i+1;
            for($j = 0; $j < count($fenlines) ; $j ++){
                if(in_array($fenlines[$j], ['p','n','b','r','q','k','P','N','B','R','Q','K'])){
                    $lineRecordData[] = $repsource[$fenlines[$j]];
                }else if(in_array($fenlines[$j],['1','2','3','4','5','6','7','8'])){
                    $columnnum = intval($fenlines[$j]);
                    for($k =0 ;$k < $columnnum ; $k++){
                         $lineRecordData[] = false;
                    }
                }
            }
            $showData[] = $lineRecordData;
        }
        $showData[] = ['','A','B','C','D','E','F','G','H'];
        return $showData;
    }
    
    public function index(){
        $fen = request()->input('fen');
        
        if(empty($fen)){
            
            return $this->rand();
        }
        
        $showData = $this->getShowDataByFen($fen);
         return view('chess.index', ['showData'=>$showData, 'title'=>'Ny FEN' ])->render();
    }
    
    public function rand(){
        $fan = new \App\Models\FanModel();
        $fone = $fan->take(1)->orderBy(\DB::raw('RAND()'))->select('fenstr')->get()->toArray ();
        
        $showData = $this->getShowDataByFen($fone[0]['fenstr']);
        if(request()-> ajax()){
            die(json_encode(['showData'=>$showData]));
        }
       return view('chess.index', ['showData'=>$showData, 'title'=>'Ny FEN' ])->render();
    }
}
