<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class FenSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('fen')->insert([
           ['fenstr'=>'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR'],
            ['fenstr'=>'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR'],
            ['fenstr'=>'rnbqkbnr/pp1ppppp/8/2p5/4P3/8/PPPP1PPP/RNBQKBNR'],
            ['fenstr'=>'rnbqkbnr/pp1ppppp/8/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R']
        ]);
    }
}
