<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>FEN Display Tool</title>
        <style>
            body,document,*{
                padding: 0px;
                margin:0px;
            }
            body {
                font-family: 'Nunito', sans-serif;
            }
            .card{
                display: inline-block;
                width:12.5%;
                height:100%;
                z-index: 10;
                text-align: center;
            }
            .board{
                display:flex;
                flex-direction: row;
                justify-content: space-around;
                flex-wrap: wrap-reverse;
                width: 100%;
                background-color: #cccccc29;
                padding-top: 15px;
                padding-bottom: 15px;
            }
            .rboard{
                position:relative;
                display:flex;
                flex-direction: column;
                justify-content: center;
            }
            .rboard3{
                min-width: 560px;
                min-height:560px;
            }
            .rboard2{
                display:flex;
                flex-direction: row;
                justify-content:space-around;
                width: 100%;
                height:100%;
            }
            .rboardline{
                display:flex;
                flex-direction: row;
                height:12.5%;
                justify-content: space-around;
                width:100%;
            }
            img.rboardimg{
                position:absolute;
                left:0px;
                top:0px;
                width:100%;
                height:100%;
                z-index:1;
            }
            a{
                text-decoration: none;
            }
            @media screen and (max-width: 600px) {
               .rboard3{
                    min-width: 480px;
                    min-height:480px;
                }
            }
            
            @media screen and (max-width:  480px) {
               .rboard3{
                    min-width: 320px;
                    min-height:320px;
                }
            }
            
            @media screen and (max-width:  370px) {
               .rboard3{
                    min-width: 330px;
                    min-height:330px;
                }
            }
            
            @media screen and (max-width:  320px) {
               .rboard3{
                    min-width: 300px;
                    min-height:300px;
                }
            }
        </style>
    </head>
    <body class="antialiased">
        <div style="text-align:center;height:60px;">
            <h1>FEN Display Tool</h1>
        </div>
        <div class="board">
            <div style="display: flex;flex-direction: row; justify-content: center;">
                <div style="display: flex;flex-direction: column; justify-content: space-between;">
                    @foreach([1,2,3,4,5,6,7,8] as $rn)
                    <div style="padding-right:15px;vertical-align: middle;height:12.5%;">
                           {{$rn}}
                    </div>
                    @endforeach
                </div>
                <div>
                    <div  class="rboard" >
                        <img class="rboardimg" src="/static/img/board.png" />
                        <div class="rboard2">
                            <div class="rboard3" style="display: flex;flex-direction: column; justify-content: space-around;">
                                @foreach($showData as $rowData)
                                <div style="margin-top: 15px;" class="rboardline" >
                                    @foreach($rowData as $data)
                                        <span class="card">
                                           @if($data)
                                            <img style="width:75%;height:75%;"  src="/static/img/{{$data}}" />
                                           @endif
                                        </span>
                                    @endforeach
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <div style="display: flex;flex-direction: row; justify-content: space-between;">
                        @foreach(['A','B','C','D','E','F','G','H'] as $rnc)
                        <span style="text-align: center;padding-top:15px;vertical-align: middle;width:12%;">
                               {{$rnc}}
                        </span>
                        @endforeach
                    </div>
                </div>
                
            </div>
            
            <div style="text-align:center;display:flex;flex-direction: row;justify-content: center;margin-bottom: 30px;">
                <a href="/rand">
                    <div style="width: 120px;
                      cursor: pointer;
                    line-height: 40px;
                    height:40px;
                    font-weight: bold;
                    text-align: center;
                    background-color: #2196f3;
                    color: #ffffff;">
                    {{$title}}
                  </div>
                </a>
            </div>
        </div>
        <div style="text-align: center;height:30px;position: absolute;bottom: 0px;width:100%;">
            <h3>FEN Display Tool by xxx</h3>
        </div>
    </body>
</html>
