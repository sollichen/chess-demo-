#go to the web demo working directory
cd ./example-app/

#change database user name and password you use in .env file
DB_USERNAME=
DB_PASSWORD=

#start mysql and create database

CREATE DATABASE chess_test


#Drop All Tables & Migrate
php artisan migrate:fresh --seed

#seed
php artisan db:seed --class=FenSeeder


#come to web application directory and start server
php artisan serve --host=0.0.0.0 --port=8080

#change to your ip and see how it works
http://x.x.x.x:8080/rand