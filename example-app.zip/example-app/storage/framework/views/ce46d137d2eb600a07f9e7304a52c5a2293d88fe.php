<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>FEN Display Tool</title>
        <script src="/static/js/jquery-3.6.0.min.js"></script>
        <style>
            body,document,*{
                padding: 0px;
                margin:0px;
            }
            body {
                font-family: 'Nunito', sans-serif;
            }
            .board{
                height: 630px;
                width: 630px;
            }
            .linecard{
                margin:0px;
                padding:0px;
                height:70px;
                display: flex;
                flex-direction: row;
                justify-content: flex-start;
            }
            .card{
                width:12.5%;
                height:100%;
                margin: 0px;
                padding: 0px;
                display: block;
            }
            .middleShow{
                display: flex;
                flex-direction: row;
                justify-content: space-around;
                flex-wrap: wrap-reverse;
                padding-bottom: 30px;
                padding-top: 30px;
                width:100%;
                background-color: #cccccc29;
            }
            a.showRandA{
                text-decoration: none;
            }
            
            .headtitle{
                background-color: #fff;
            }
                
            @media  screen and (max-width: 650px) {
               .board{
                    width: 585px;
                    height:585px;
                }
                .linecard{
                    height:65px;
                }
                .headtitle{
                    background-color: #000;
                    color: #fff;
                }
            }
            
            
            @media  screen and (max-width:  600px) {
                    .board{
                         width: 540px;
                         height:540px;
                     }
                     .linecard{
                         height:60px;
                     }
                      .headtitle{
                         background-color: #000;
                         color: #fff;
                     }
                     
                     
                }
            
            @media  screen and (max-width:  560px) {
                .board{
                     width: 495px;
                     height:495px;
                 }
                 .linecard{
                     height:55px;
                 }
                  .headtitle{
                     background-color: #000;
                     color: #fff;
                 }
             }
           
            @media  screen and (max-width:  500px) {
                .board{
                     width: 450px;
                     height:450px;
                 }
                 .linecard{
                     height:50px;
                 }
                  .headtitle{
                     background-color: #000;
                     color: #fff;
                 }
             }
            @media  screen and (max-width:  450px) {
               .board{
                    width: 405px;
                    height:405px;
                }
                .linecard{
                    height:45px;
                }
                 .headtitle{
                    background-color: #000;
                    color: #fff;
                }
            }
            
            @media  screen and (max-width:  420px) {
               .board{
                    width: 360px;
                    height:360px;
                }
                .linecard{
                    height:40px;
                }
                 .headtitle{
                    background-color: #000;
                    color: #fff;
                }
            }
            @media  screen and (max-width:  420px) {
               .board{
                    width: 360px;
                    height:360px;
                }
                .linecard{
                    height:40px;
                }
                 .headtitle{
                    background-color: #000;
                    color: #fff;
                }
            }
            
            @media  screen and (max-width:  380px) {
               .board{
                    width: 315px;
                    height:315px;
                }
                .linecard{
                    height:35px;
                }
                 .headtitle{
                    background-color: #000;
                    color: #fff;
                }
            }
        </style>
    </head>
    <body class="antialiased">
        <div class="headtitle" style="text-align:center;height:60px; line-height:60px;">
            <h1>FEN Display Tool</h1>
        </div>
        <div class="middleShow">
            <div class="board">
                <?php $__currentLoopData = $showData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $rowData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="linecard">
                    <?php $__currentLoopData = $rowData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card" id="<?php echo e($i); ?><?php echo e($j); ?>" style="
                             <?php if($data &&  $j != 0 && $i != 8): ?>
                             background-image:url(/static/img/<?php echo e($data); ?>);
                             <?php endif; ?>
                             background-repeat: no-repeat;
                             <?php if($j == 0): ?>
                                display: flex;
                                flex-direction: column;
                                justify-content: center;
                                text-align: right;
                                padding-right: 5px;
                                width:20px;
                             <?php else: ?>
                                text-align: center;
                             <?php endif; ?>
                             <?php if(($i+$j)%2 == 0 && $j != 0 && $i != 8): ?> background-color: #3c8fa4; 
                             <?php else: ?> 
                                <?php if($j == 0 || $i == 8): ?> 
                                
                                <?php else: ?>
                                  background-color: #ffffff;
                                <?php endif; ?>
                                    
                                <?php endif; ?>">
                            <?php if($j == 0 || $i == 8): ?> 
                                <?php echo e($data); ?>

                             <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div style="text-align:center;display:flex;flex-direction: row;justify-content: center;margin-bottom: 30px;">
                    <div id="getDataByAjax" style="width: 120px;
                      cursor: pointer;
                    line-height: 40px;
                    height:40px;
                    font-weight: bold;
                    text-align: center;
                    background-color:#3c8fa4; 
                    color: #ffffff;">
                    <?php echo e($title); ?>

                  </div>
            </div>
        </div>
        <div style="text-align: center;height:60px;line-height: 60px;width:100%;">
            <h3>FEN Display Tool by xxx</h3>
        </div>
        
        <script type="text/javascript">
            $(document).ready(function(){
                $('#getDataByAjax').click(function(){
                    $.ajax({
                        url:'/rand',
                        type:'get',
                        dataType:'json',
                        success:function(idata){
                            var data = idata.showData;
                            console.log(data);
                            for(var i = 0; i < data.length -1; i ++){
                                for(var j = 1 ; j < data[i].length; j ++){
                                    var idStr = i+""+j;
                                    console.log( $("#"+idStr));
                                    if(data[i][j] ){
                                       $("#"+idStr).css("background-image","url(/static/img/"+ data[i][j] +")")
                                    }else{
                                        $("#"+idStr).css("background-image","")
                                    }
                                }
                            }
                        }
                    })
                });
            });
        </script>
    </body>
</html>
<?php /**PATH /mnt/hgfs/phpweb/chess/example-app/resources/views/chess/index.blade.php ENDPATH**/ ?>